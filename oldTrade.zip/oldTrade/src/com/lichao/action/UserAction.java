package com.lichao.action;

import java.sql.Timestamp;
import java.util.List;

import com.lichao.bean.User;
import com.lichao.persistence.PersistenceUser;
import com.lichao.utill.CalendarUtil;
import com.lichao.utill.MD5Util;

public class UserAction extends BaseAction {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static int helloCount = 0;
	private String authCode;
	private User user;

	public String execute() throws Exception {
		mLoger.error("app start");
		return SUCCESS;
	}
	
	public String logout() throws Exception {
		   mSession.remove(BaseAction.enumSession.user.toString());
		   
		return LOGIN;
	}
	
	/**
	 * 登录
	 * @return
	 * @throws Exception
	 */
	public String login() throws Exception {
		if (mSession.get("yanzheng") != null) {
			String authSession = mSession.get("yanzheng").toString();
			if (authSession.equals(authCode)) {
				if (user != null) {
					PersistenceUser persistenceLayer = (PersistenceUser) mContext.getBean("persistenceUser");
					if (user.getName() != null) {
						List<User> users = persistenceLayer.getUserDAO().findByName(user.getName());
						if(users.size()>0){
							if(users.get(0).getPwd().equals(MD5Util.MD5(user.getPwd()) )){
								Timestamp currentTime=new Timestamp(System.currentTimeMillis());
								users.get(0).setTimeCurrent(currentTime);
								persistenceLayer.updateUser(users.get(0));
								successMessage("用户登录成功！");
								user.setCurrentLogin(CalendarUtil.getDate(currentTime));
								mSession.put(BaseAction.enumSession.user.toString(), user);
							}else{
								errorMessage("用户密码错误！");
								return null;
							}
						}else{
							errorMessage("无此用户！");
							return null;
						}
					}
				}
			} else {
				errorMessage("验证码错误！");
				return null;
			}
		} else {
			errorMessage("请输入验证码");
			return null;
		}
		return null;
	}

	/**
	 * 注册
	 * @return
	 * @throws Exception
	 */
	public String insert() throws Exception {
		
		if (mSession.get("yanzheng") != null) {
			String authSession = mSession.get("yanzheng").toString();
			if (authSession.equals(authCode)) {
				if (user != null) {
					PersistenceUser persistenceLayer = (PersistenceUser) mContext.getBean("persistenceUser");
					if (user.getName() != null) {
						List<User> users = persistenceLayer.getUserDAO().findByName(user.getName());
						if (users.size() == 0) {
							Timestamp currentTime=new Timestamp(System.currentTimeMillis());
							user.setTimeCreate(currentTime);
							user.setTimeCurrent(currentTime);
							user.setPwd(MD5Util.MD5(user.getPwd()));
							user.setCurrentLogin(CalendarUtil.getDate(currentTime));
							user.setPower(1);
							user.setRangeBuy(1);
							user.setRangeSell(1);
							
							persistenceLayer.addUser(user);
							successMessage("注册成功！");
							mSession.put(BaseAction.enumSession.user.toString(), user); //默认登录
							return null;
						}else{
							errorMessage("用户名已被占用！");
							return null;
						}
					}
				}
			} else {
				errorMessage("验证码错误！");
				return null;
			}
		} else {
			errorMessage("请输入验证码");
			return null;
		}
		return null;
	}

	public int getHelloCount() {
		return helloCount;
	}

	public void setHelloCount(int helloCount) {
		UserAction.helloCount = helloCount;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getAuthCode() {
		return authCode;
	}

	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

}
